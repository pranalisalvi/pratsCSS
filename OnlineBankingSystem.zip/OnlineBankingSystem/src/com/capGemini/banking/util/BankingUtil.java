package com.capGemini.banking.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class BankingUtil {

	static Connection conn=null;
	public static Connection obtainConnection() 
	{
		InitialContext context;
		try {
			context=new InitialContext();
			DataSource source=(DataSource) context.lookup("java:/OracleDS"); //jdbc/ConPool
			conn=source.getConnection();
		} catch (NamingException e) {
			
			e.printStackTrace();
			//throw new EmployeeException("Problem in Connection");
		} catch (SQLException e) {
			
			e.printStackTrace();
			//throw new EmployeeException("Problem in Connection");
		}
		
		return conn;
		
	}
}
