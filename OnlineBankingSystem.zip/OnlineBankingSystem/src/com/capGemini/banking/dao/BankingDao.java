package com.capGemini.banking.dao;


import com.capGemini.banking.dto.AccountDto;
import com.capGemini.banking.dto.CustomerDto;
import com.capGemini.banking.dto.UserDto;
import com.capGemini.banking.exception.BankingException;

public interface BankingDao {
int addCustDetails(CustomerDto cust,AccountDto acc) throws BankingException;
 UserDto getUserDto(long accId) throws BankingException;
 CustomerDto getCustomerDetails(long accId) throws BankingException;
 boolean updateDetails(CustomerDto customer) throws BankingException;
long validateUserId(int userId, String password) throws BankingException;
int isValidUser(int userId, String password) throws BankingException;

}
