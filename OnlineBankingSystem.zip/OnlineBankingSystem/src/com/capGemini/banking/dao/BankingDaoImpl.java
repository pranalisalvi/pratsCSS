package com.capGemini.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capGemini.banking.dto.AccountDto;
import com.capGemini.banking.dto.CustomerDto;
import com.capGemini.banking.dto.UserDto;
import com.capGemini.banking.exception.BankingException;
import com.capGemini.banking.util.BankingUtil;

public class BankingDaoImpl implements BankingDao {
	Connection conn = null;
	PreparedStatement ps = null;
	CustomerDto cust = new CustomerDto();
	AccountDto acc = new AccountDto();

	public BankingDaoImpl() {

	}

	@Override
	public int addCustDetails(CustomerDto cust, AccountDto acc)
			throws BankingException {
		conn = BankingUtil.obtainConnection();

		int accId = getAccountId();
		String query = "INSERT INTO Customer values(?,?,?,?,?,?)";
		try {
			ps = conn.prepareStatement(query);
			ps.setLong(1, accId);
			ps.setString(2, cust.getCustomer_name());
			ps.setString(3, cust.getEmail());
			ps.setString(4, cust.getAddress());
			ps.setString(5, cust.getPancard());
			ps.setString(6, cust.getMobileNo());

			int status = ps.executeUpdate();
			int statusAcc = 0;
			if (status > 0) {
				String query1 = "INSERT INTO AccountMaster values(?,?,?,sysdate)";
				ps = conn.prepareStatement(query1);
				ps.setLong(1, accId);
				ps.setString(2, acc.getAccount_Type());
				ps.setDouble(3, acc.getAccount_Balance());
				statusAcc = ps.executeUpdate();

			}
			if (statusAcc > 0) {
				int userId = getUserId();
				String passwordLogin = generatePassword(8, false);
				String passwordTransact = generatePassword(8, false);
				String query2 = "INSERT INTO UserTable (Account_ID,user_id,login_password,TRANSACTION_PASSWORD) values(?,?,?,?)";
				ps = conn.prepareStatement(query2);
				ps.setLong(1, accId);
				ps.setInt(2, userId);
				ps.setString(3, passwordLogin);
				ps.setString(4, passwordTransact);
				int UserStatus = ps.executeUpdate();

			} else {
				System.out.println("not inserted");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {

				e.printStackTrace();
				throw new BankingException("In Finally");
			}
		}

		return accId;
	}

	public int getAccountId() {
		int accId = 0;
		String query = "SELECT accountId_seq.NEXTVAL from dual";
		try {
			conn = BankingUtil.obtainConnection();
			ps = conn.prepareStatement(query);
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				accId = res.getInt(1);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return accId;
	}

	public int getUserId() {
		int userId = 0;
		String query = "SELECT userId_seq.NEXTVAL from dual";
		try {
			conn = BankingUtil.obtainConnection();
			ps = conn.prepareStatement(query);
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				userId = res.getInt(1);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return userId;
	}

	public String generatePassword(int length, boolean special) {
		String password = null;
		int iteration = 0;
		double randomNumber = 0;
		while (iteration < length) {
			randomNumber = ((Math.floor(Math.random() * 100)) % 94) + 33;

			if (!special) {
				if ((randomNumber >= 33) && (randomNumber <= 47)) {
					continue;
				}
				if ((randomNumber >= 58) && (randomNumber <= 64)) {
					continue;
				}
				if ((randomNumber >= 91) && (randomNumber <= 96)) {
					continue;
				}
				if ((randomNumber >= 123) && (randomNumber <= 126)) {
					continue;
				}
			}
			iteration++;
			char a = (char) randomNumber;
			password += String.valueOf(a);
		}
		String password1 = password.substring(4, length + 4);
		return password1;

	}

	public UserDto getUserDto(long accId) {
		conn = BankingUtil.obtainConnection();
		String query = "SELECT user_id,login_password FROM UserTable where Account_ID=?";
		UserDto uDto = new UserDto();
		try {
			ps = conn.prepareStatement(query);
			ps.setLong(1, accId);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				uDto.setUser_id(rs.getInt("user_id"));
				uDto.setLogin_password(rs.getString("login_password"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return uDto;

	}

	@Override
	public CustomerDto getCustomerDetails(long accId) throws BankingException {
		conn = BankingUtil.obtainConnection();
		String query = "SELECT address,mobileno  FROM Customer where Account_ID=?";
		CustomerDto custDto = new CustomerDto();
		try {
			ps = conn.prepareStatement(query);
			ps.setLong(1, accId);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				custDto.setAddress(rs.getString(1));
				custDto.setMobileNo(rs.getString(2));

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return custDto;
	}

	@Override
	public boolean updateDetails(CustomerDto customer) throws BankingException {
		conn = BankingUtil.obtainConnection();
		String address = customer.getAddress();
		String mobile = customer.getMobileNo();

		try {
			if (address.length() > 0 && mobile.length() > 0) {
				String query = "update customer set address=?, mobileno=? where Account_ID=?";
				ps = conn.prepareStatement(query);
				ps.setString(1, address);
				ps.setString(2, mobile);
				ps.setLong(3, customer.getAccount_ID());
			} else if (mobile.length() > 0) {
				String query = "update customer set  mobileno=? where Account_ID=?";

				ps = conn.prepareStatement(query);
				ps.setString(1, mobile);
				ps.setLong(2, customer.getAccount_ID());
			} else if (address.length() > 0) {
				String query = "update customer set address=? where Account_ID=?";
				ps = conn.prepareStatement(query);
				ps.setString(1, address);
				ps.setLong(2, customer.getAccount_ID());
			}
			int c = ps.executeUpdate();
			if (c > 0) {
				System.out.println("updated");
				return true;
			}

		} catch (SQLException e) {
			throw new BankingException("Connection failed", e);
		}

		return false;
	}

	@Override
	public long validateUserId(int userId, String password)
			throws BankingException {

		String qry = "SELECT LOGIN_PASSWORD,ACCOUNT_ID FROM USERTABLE WHERE USER_ID=?";

		try {
			conn = BankingUtil.obtainConnection();
			ps = conn.prepareStatement(qry);
			ps.setInt(1, userId);

			ResultSet rs1 = ps.executeQuery();

			if (rs1.next()) {
				if (password.equals(rs1.getString("LOGIN_PASSWORD"))) {
					return rs1.getLong("ACCOUNT_ID");
				}
			} else {
				throw new BankingException("User Id is Invalid.");

			}
		} catch (SQLException e) {
			throw new BankingException("JDBC Connection failed", e);
		}

		return 0;
	}

	@Override
	public int isValidUser(int userId, String password) throws BankingException {
		String result = null;
		boolean flag = false;
		ResultSet rs=null;
		conn = BankingUtil.obtainConnection();
		String query = "SELECT User_Id,User_type FROM UserTable ";
		try {
			
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				
				if (rs.getInt("User_Id") == userId) {
					
					result = rs.getString("User_type");
					
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new BankingException("Database closing failed", e);
			}
		}
		if (result != null) {
			conn = BankingUtil.obtainConnection();
			String query1 = "SELECT Login_Password FROM UserTable where User_Id=?";
			try {
				ps = conn.prepareStatement(query1);
				ps.setInt(1, userId);
				rs = ps.executeQuery();
				while (rs.next()) {
					if (password.equals(rs.getString("Login_Password"))) {
						System.out.println(password);
						flag = true;
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (ps != null) {
						ps.close();
					}
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (flag == true && result.equals("Admin")) {
				return 1;
			} else if (flag == true && result.equals("users")) {
				return 2;
			} else {
				return 0;
			}
		}

		return 3;

	}
	
}
